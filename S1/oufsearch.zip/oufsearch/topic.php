<?php
require "inc/inc.php";

if(!isset($_GET['id'])){
	header('Location:'.WEBROOT);
}


$req = $bdd->prepare('SELECT * FROM topics WHERE id = :id');
$req->execute(array('id' => $_GET['id']));

$topic = $req->fetch(PDO::FETCH_ASSOC);


$req = $bdd->prepare("SELECT * FROM messages WHERE topic = :topic ORDER BY DATE ASC");
$req->execute(array('topic' => $_GET['id']));

$reponses = $req->fetchAll(PDO::FETCH_ASSOC);

$isFollowed = 'btn-warning';
$_COOKIE['ouf'] = unserialize($_COOKIE['ouf']);

foreach($_COOKIE['ouf']['follows'] as $index => $followed){
	if($followed == $_GET['id']){
		$isFollowed = 'btn-success';
		break;
	}
}


include "views/topic.php";