<?php

require "inc/inc.php";

include ROOT.'views/accueil.php';