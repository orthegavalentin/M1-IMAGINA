<?php
require "inc/inc.php";
$id = $_GET['id'];//itopic
$vieuxbooleen = false;

$_COOKIE['ouf'] = unserialize($_COOKIE['ouf']);

foreach($_COOKIE['ouf']['follows'] as $index => $followed){
	if($followed == $id){
		//on supprime
		unset($_COOKIE['ouf']['follows'][$index]);
		$vieuxbooleen = true;
		echo 'btn-warning';
		break;
	}
}


if(!$vieuxbooleen){
	//on ajoute
	$_COOKIE['ouf']['follows'][] = $id;
	echo 'btn-success';
}

setcookie("ouf", serialize($_COOKIE['ouf']),time()+365*24*3600);

