<?php
$db_version = 'offline';
//6AVdnWEICS

$db['offline']['hostname'] = 'localhost';
$db['offline']['database'] = 'vbazia';
$db['offline']['username'] = 'vbazia';
$db['offline']['password'] = '6AVdnWEICS';

try{
	$bdd = new PDO('mysql:host='.$db[$db_version]['hostname'].';dbname='.$db[$db_version]['database'].'', $db[$db_version]['username'], $db[$db_version]['password'], array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
}
catch (Exception $e){
    die('Erreur : ' . $e->getMessage());
}
