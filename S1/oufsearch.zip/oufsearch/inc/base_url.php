<?php
define('ROOT', str_replace('index.php', '', $_SERVER['SCRIPT_FILENAME']));
define('WEBROOT', str_replace('index.php', '', 'http://'.$_SERVER['SERVER_NAME'].''.$_SERVER['SCRIPT_NAME']));