<?php
 // error_reporting(E_ALL | E_STRICT);
 // ini_set('display_errors', 1);
 // ini_set('log_errors', 1);
 // ini_set('error_log', "log.txt");

//COOKIE STYLE
/*
$_COOKIE['ouf'] = array(
	'follow' => array(ID TOPICS),
	'participated' => array(ID TOPICS),
	'voted' => array(ID MESSAGE)
)


$r .= 'SELECT topics.id, topics.sujet, topics.date_sujet
	FROM messages, topics
	WHERE messages.topic = topics.id
	AND (';

		foreach ($ouftags as $ouftag) {
			if(!in_array($ouftag, $not_ouftag)) {
				$r .= " messages.message LIKE '%".$ouftag."%' OR topics.sujet LIKE '%".$ouftag."%' OR";
			}
		}
		$r = substr($r, 0, strlen($r) - 3);
		$r .= ")";
*/


 require "inc/bdd.php";
 require "inc/base_url.php";
 require "inc/cookies.php";
 require "inc/functions.php";

