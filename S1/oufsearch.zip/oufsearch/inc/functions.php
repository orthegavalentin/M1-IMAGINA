<?php
function functionSearch($s, $not_ouftag = null){
	global $bdd;
//bazia aime les bites
	$topics = array();

        //not_ouftag = tab de ouftag interdit
        //todo
        //25 par page

	switch ($s) {
		case ':last_topics':
		$req = $bdd->prepare('SELECT * FROM topics ORDER BY id DESC LIMIT 0, 100');
		$req->execute();
		$res = $req->fetchAll(PDO::FETCH_ASSOC);
		foreach ($res as &$topic) {
			$topic['ouftags'] = getTopicOUftags($topic['id']);
			$topic['nb'] = getNbReponses($topic['id']);
			$topic['messages'] = getMessages($topic['id']);
		}
		$topics = $res;
		break;

		case ':last_messages':
                        # code...
		$req = $bdd->prepare('SELECT t.id, t.sujet, t.date_sujet, (SELECT m.date FROM messages m WHERE m.topic = t.id ORDER BY m.date DESC LIMIT 1) as last_date FROM topics t ORDER BY last_date DESC LIMIT 0, 100');
		$req->execute();
		$res = $req->fetchAll(PDO::FETCH_ASSOC);
		foreach ($res as &$topic) {
			$topic['ouftags'] = getTopicOuftags($topic['id']);
			$topic['nb'] = getNbReponses($topic['id']);
			$topic['messages'] = getMessages($topic['id']);
		}
		$topics = $res;
		break;

		case ':followed':

                        # code...
		$f = unserialize($_COOKIE['ouf']);
		foreach ($f['follows'] as $key => &$followed) {
			$id = $followed;
			$followed = getTopic($id);
			$followed['nb'] = getNbReponses($id);
			$followed['messages'] = getMessages($id);
			$followed['ouftags'] = getTopicOuftags($id);
		}
		$topics = array_reverse($f['follows']);
		break;

		case ':participated':
		$p = unserialize($_COOKIE['ouf']);
		foreach ($p['participated'] as $key => &$followed) {
			$id = $followed;
			$followed = getTopic($id);
			$followed['nb'] = getNbReponses($id);
			$followed['messages'] = getMessages($id);
			$followed['ouftags'] = getTopicOuftags($id);
		}
		$topics = array_reverse($p['participated']);
		break;

		case ':popular':
                        # code...
		$req = $bdd->prepare('SELECT t.id, t.sujet, COUNT(m.id) as nb FROM topics t, messages m WHERE m.topic = t.id GROUP BY t.id ORDER BY nb DESC');
		$req->execute();
		$res = $req->fetchAll(PDO::FETCH_ASSOC);
		foreach ($res as &$topic) {
			$topic['ouftags'] = getTopicOUftags($topic['id']);
			$topic['nb'] = getNbReponses($topic['id']);
			$topic['messages'] = getMessages($topic['id']);
		}
		$topics = $res;

		break;

		case ':ouftags':
                        # code...
		$req = $bdd->prepare('SELECT *, nbuse as nb FROM ouftag ORDER BY nb DESC');
		$req->execute();
		$res = $req->fetchAll(PDO::FETCH_ASSOC);
		$topics = $res;
		break;

		default:
		$topics = searchOuftags(explode(" ", $s), $not_ouftag);
		break;
	}
	return $topics;
}

function getBlocInformations($s){
	$res = array_slice(functionSearch($s), 0, 5);
	return $res;
}


function searchOuftags($ouftags, $not_ouftag) {

	global $bdd;

	$results = array();

	$r = "";

	$r .= 'SELECT COUNT(*) as anus, topics.id, topics.sujet, topics.date_sujet
	FROM messages, topics
	WHERE messages.topic = topics.id
	AND (';

		foreach ($ouftags as $ouftag) {
			if(!in_array($ouftag, $not_ouftag) && !empty($ouftag)) {
				$r .= " messages.message LIKE '%".$ouftag."%' OR topics.sujet LIKE '%".$ouftag."%' OR";
			}
		}
		$r = substr($r, 0, strlen($r) - 3);
		$r .= ")";

		$r .= " GROUP BY topics.id ORDER BY anus DESC";

$req = $bdd->prepare($r);
$req->execute();

$topics = $req->fetchAll();
foreach ($topics as $topic) {

	$topic['messages'] = getMessages($topic['id']);

	$topic['ouftags'] = getTopicOuftags($topic['id']);

	$ses_ouftags = array();
	foreach ($topic['ouftags'] as $ouf) {
		$ses_ouftags[] = $ouf[0];
	}
	
	$bool = false;
	foreach ($ses_ouftags as $ouf) {
		if(in_array($ouf, $not_ouftag)){
			$bool = true;
			break;
		}
	}
	if(!$bool){
		$results[] = $topic;
	}
	//$results[] = $topic;
}
return $results;
}


function getOufTagFromString($s){
	$ouftags = array();

	$i = 0;
	$ouftag = "";

	while($i < strlen($s)) {
		$char = $s{$i};
		if(!ereg("[a-zA-Z0-9/#éêàœôâèïëö]", $char)) {
			if(strlen($ouftag) > 1) {
				$ouftags[] = $ouftag;
			}
			$ouftag = "";
			$i++;
			continue;
		}

		if($char == "#") {
			if(strlen($ouftag) > 1) {
				$ouftags[] = $ouftag;
				
			}
			$ouftag = "#";
			$i++;
			continue;
		}

		if(strlen($ouftag) > 0) {
			$ouftag .= $char;
		}

		$i++;
	}
	if(strlen($ouftag) > 1) {
		$ouftags[] = $ouftag;
	}

	return $ouftags;
}

function replace_links($content)
{
	if (preg_match('#(http://[^\s]+(?=\.(jpe?g|png|gif)))#i', $content))
	{
		$content = preg_replace('#(http://[^\s]+(?=\.(jpe?g|png|gif)))(\.(jpe?g|png|gif))#i', '<img src="$1.$2" style="max-width:600px;max-height:400px" alt="$1.$2" />', $content);
	}
	else
	{
		$content = preg_replace('@((https?://)?([-\w]+\.[-\w\.]+)+\w(:\d+)?(/([-\w/_\.]*(\?\S+)?)?)*)@', '<a href="$1" target="blank">$1</a>', $content);
	}

	return $content;
}

function getTopicOuftags($idTopic){
	global $bdd;
	$req = $bdd->prepare('SELECT DISTINCT o.ouftag FROM messages m, ouftag o, message_ouftag mo WHERE topic = :id AND m.id = mo.id_m AND o.id = mo.id_o');
	$req->execute(array('id' => $idTopic));
	return $req->fetchAll();
}

function getNbReponses($idTopic){
	global $bdd;
	$req = $bdd->prepare('SELECT COUNT(*) as nb FROM messages WHERE topic = :id');
	$req->execute(array('id' => $idTopic));
	$res = $req->fetch();
	return $res['nb'];
}

function getTopic($idTopic){
	global $bdd;
	$req = $bdd->prepare('SELECT * FROM topics WHERE id = :id');
	$req->execute(array('id' => $idTopic));
	$res = $req->fetch(PDO::FETCH_ASSOC);
	return $res;
}

function getMessages($idTopic){
	global $bdd;
	$req = $bdd->prepare("SELECT * FROM messages WHERE topic = :topic ORDER BY DATE ASC");
	$req->execute(array('topic' => $idTopic));
	return $req->fetchAll(PDO::FETCH_ASSOC);
}

function addOuftag($o, $id){
	global $bdd;
	$req1 = $bdd->prepare('SELECT * FROM ouftag WHERE ouftag = :o');
	$req1->execute(array('o' => $o));
	$res = $req1->fetchAll();
	if(count($res) == 0){
		//pas créé
		$req2 = $bdd->prepare('INSERT INTO ouftag (ouftag, nbuse) VALUES (:o, :nb)');
		$req2->execute(
			array(
				'o' => $o,
				'nb' => 1
				));

		$ido = $bdd->lastInsertId();

		$req3 = $bdd->prepare('INSERT INTO message_ouftag (id_m, id_o) VALUES (:id, :o)');
		$req3->execute(array(
			'id' => $id,
			'o' => $ido
			));

	}else{
		$newnb = $res[0]['nbuse']*1+1;
		$bdd->query('UPDATE ouftag SET nbuse = '.$newnb.' WHERE id = '.$res[0]['id']);

		$req4 = $bdd->prepare('INSERT INTO message_ouftag (id_m, id_o) VALUES (:id, :o)');
		$req4->execute(array(
			'id' => $id,
			'o' => $res[0]['id']
			));
	}
}

function addMessage($m, $topic, $pere = null){
	global $bdd;
	$req = $bdd->prepare('INSERT INTO messages (message, date, note, topic, pere) VALUES (:m, NOW(), 0, :t, :p)');
	$req->execute(array('m' => $m, 't' => $topic, 'p' => $pere));
	return $bdd->lastInsertId();
}

function voter($id, $note){
	global $bdd;
	$req = $bdd->prepare('SELECT * FROM messages WHERE id = :id');
	$req->execute(array('id' => $id));


	$res = $req->fetch();

	if($note > 0){
		$value = 1;
	}else{
		$value = -1;
	}

	$newnote = $res['note'] + $value;

	$req2 = $bdd->prepare('UPDATE messages SET note = :note WHERE id = :id');
	$req2->execute(array(
		'id' => $id,
		'note' => $newnote));

	return $newnote;
}

function tri($tab){
	$leau = array();
	$min = 999999999;
	$value = "";


	while(count($tab) > 0){
		foreach ($tab as $ouf => $val) {
			if($val < $min){
				$min = $val;
				$value = $ouf;
			}
		}
		unset($tab[$value]);
		$leau[$value] = $min;
		$min = 999999999;
	}

	return $leau;

}