<?php

require "inc/inc.php";


if(isset($_POST['submit'])&& isset($_POST['sujet'])&& isset($_POST['message'])){
	$req = $bdd->prepare('INSERT INTO topics (sujet) values (:sujet)');
	$req->execute(array('sujet' => $_POST['sujet']));

	$id = $req->lastInsertId();

	//ajout topic
	addMessage($_POST['message'], $id);
	header('Location:'.WEBROOT.'?p=topic&id='.$id);
}else{
	//affichage formulaire
}