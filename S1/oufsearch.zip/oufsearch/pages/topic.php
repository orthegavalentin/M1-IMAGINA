<?php

$req = $bdd->prepare("SELECT * FROM messages WHERE topic = :topic ORDER BY DATE ASC");
$req->execute(array('topic' => $_GET['id']));

$reponses = $req->fetchAll(PDO::FETCH_ASSOC);

include ROOT."/views/messages.php";