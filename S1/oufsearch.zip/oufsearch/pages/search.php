<?php
require "inc/inc.php";

//$results = functionSearch($_GET['s']);

include 'views/search.php';
