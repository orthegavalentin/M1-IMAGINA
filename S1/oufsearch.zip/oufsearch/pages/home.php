<?php
include ROOT.'views/accueil.php';