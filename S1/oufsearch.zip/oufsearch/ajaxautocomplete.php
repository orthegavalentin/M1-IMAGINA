<?php
print_r($_COOKIE);
echo '<br/>';
print_r(unserialize($_COOKIE['ouf']));