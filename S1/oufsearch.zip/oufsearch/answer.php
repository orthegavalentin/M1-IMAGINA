<?php
require "inc/inc.php";
if(isset($_POST['message'])){
	$id = addMessage($_POST['message'], $_GET['id']);
	$ouftags = getOufTagFromString($_POST['message']);
	foreach ($ouftags as $ouf) {
		addOuftag($ouf, $id);
	}

	$_COOKIE['ouf'] = unserialize($_COOKIE['ouf']);

	foreach($_COOKIE['ouf']['participated'] as $index => $participated){
		if($participated == $_GET['id']){
		//on supprime
			unset($_COOKIE['ouf']['participated'][$index]);
			break;
		}
	}

	$_COOKIE['ouf']['participated'][] = $_GET['id'];
	setcookie("ouf", serialize($_COOKIE['ouf']),time()+365*24*3600);

}
header('Location:topic.php?id='.$_GET['id']);