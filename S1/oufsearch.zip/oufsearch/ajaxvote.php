<?php
require "inc/inc.php";
$v = unserialize($_COOKIE['ouf']);

$vieuxbooleen = false;
foreach($v['voted'] as $index => $followed){
	if($followed == $_GET['id']){
		//votons !
		$vieuxbooleen = true;
		echo 'no';
		break;
	}
}

if(!$vieuxbooleen){
	$v['voted'][] = $_GET['id'];
	setcookie("ouf", serialize($v),time()+365*24*3600);
	echo voter($_GET['id'], $_GET['note']);
}


