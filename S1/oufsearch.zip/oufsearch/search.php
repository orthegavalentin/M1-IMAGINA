<?php
require "inc/inc.php";

$delete_ouf = array();

if(isset($_GET['onuf'])){
	//on delete des trucs
	$delete_ouf = explode("|", $_GET['onuf']);
}
//PIRE CHOSE AU MONDE !!
$results2 = functionSearch($_GET['s'], array());

$results = functionSearch($_GET['s'], $delete_ouf);

$ouftags = array();

foreach ($results2 as $r) {
	foreach ($r['ouftags'] as $o) {
		if(isset($ouftags[$o['ouftag']])){
			$ouftags[$o['ouftag']]++;
		}else{
			$ouftags[$o['ouftag']] = 1;
		}
	}
}


$ouftags = array_slice(array_reverse(tri($ouftags)), 0, 5);

include "views/search.php";