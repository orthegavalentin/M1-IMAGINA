<?php

require "inc/inc.php";


if(isset($_POST['sujet']) && isset($_POST['message'])){
	if($_POST['sujet'] != "") {
	$req = $bdd->prepare('INSERT INTO topics (sujet) values (:sujet)');
	$req->execute(array('sujet' => $_POST['sujet']));

	$id = $bdd->lastInsertId();

	$messid = addMessage($_POST['message'], $id);

	$ouftags = getOufTagFromString($_POST['message']);
	foreach ($ouftags as $ouf) {
		addOuftag($ouf, $messid);
	}
 }
	//ajout topic
	header('Location:topic.php?&id='.$id);
}else{
	//affichage formulaire
	include 'views/create.php';
}