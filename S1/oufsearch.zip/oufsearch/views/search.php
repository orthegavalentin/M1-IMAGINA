<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>OufSearch - Recherche</title>
  <script src="views/js/jquery-2.1.1.min.js"></script>
  <script src="views/js/bootstrap.min.js"></script>
  <script src="views/js/oufJS.js"></script>
  <link href="views/css/bootstrap.min.css" rel="stylesheet">
  <link href="views/css/oufStyle.css" rel="stylesheet">
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
    </head>

    <body>

     <div id="headerBar"></div>

     <div class="container">
      <div class="row clearfix">
       <div class="col-md-3 column">
        <a href="index.php"><h1 class="text-center styleLogo">OUFSEARCH</h1></a>
      </div>
      <div class="col-md-9 column">
        <form class="navbar-form" role="search" method="GET" action="search.php">
         <div class="input-group input-group-lg">
          <input type="text" class="form-control" name="s" placeholder="Entrez votre recherche..." value=<?php if(!empty($_GET['s'])){
            echo '"'.$_GET['s'].'"';
          }else{
            echo '""';
          }
          ?>>
          <div class="input-group-btn">
           <button type="submit" class="btn btn-primary" aria-label="Rechercher">
            <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
          </button>
        </div>
      </div>
    </form>
  </div>
</div>
<div class="row clearfix barre-tags">
 <div class="col-md-3 column">
  <a href="newtopic.php"><button type="button" class="btn btn-lg btn-primary btn-block"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> Nouveau Sujet</button></a>
</div>
<div class="col-md-3 column">
  <h4 class="text-info text-center">
   <span class="glyphicon glyphicon-tags" aria-hidden="true"></span>&nbsp; OufTags :
 </h4>
</div>
<div class="col-md-6 column">
  <?php foreach ($ouftags as $ouf => $val) { 
    if(in_array($ouf, $delete_ouf)){ ?>
        <button type="button" class="btn btn-info btn-default btn-tag ouftags disabled"><span class="glyphicon glyphicon-tag" aria-hidden="true"></span><?php echo $ouf; ?></button>
   <?php }else{ ?>
        <button type="button" class="btn btn-info btn-default btn-tag ouftags"><span class="glyphicon glyphicon-tag" aria-hidden="true"></span><?php echo $ouf; ?></button>
    <?php } 
  }?>
</div>
</div>
<div class="row clearfix">
 <div class="col-md-12 column">
  <!--BLOC APERCU TOPIC A COPIER COLLER--><!--
  <div class="panel panel-default panel-topic">
   <div class="panel-heading">
    <h3 class="panel-title">Explication du théorème de Pythagore</h3>
  </div>
  <div class="panel-body">Eius populus ab incunabulis primis ad usque pueritiae tempus extremum, quod annis circumcluditur fere trecentis, circummurana pertulit bella, deinde aetatem ingressus </div>
  <div class="panel-footer">Mathématiques</div>
</div>-->
<!--END BLOC-->

<?php
$nbpage = 10;

if(isset($_GET['onuf'])) {
  $onuf = str_replace('#', "%23", $_GET['onuf']);

} else {
  $onuf = "";
}

if(isset($_GET['p']) && $_GET['p'] > 0 && $_GET['p'] <= ceil(count($results)/$nbpage)){
 $p = $_GET['p'];
}else{
  $p = 1;
}

for($i = $nbpage * ($p - 1); $i < $nbpage * $p; $i++){
  if($i >= count($results)){
    break;
  }
  ?>
  <div class="panel panel-default panel-topic">
    <div class="panel-heading">
      <a href=<?php echo '"topic.php?id='.$results[$i]['id'].'"'; ?>><h3 class="panel-title"><?php echo $results[$i]['sujet']; ?></h3></a>
    </div>
    <div class="panel-body"><?php echo substr($results[$i]['messages'][0]['message'], 0, 400); ?></div>
    <div class="panel-footer">
      <?php foreach ($results[$i]['ouftags'] as $ouftag) {
        echo $ouftag[0].' ';
      } ?>
    </div>
  </div>
  <?php } ?>

  <div class="text-center">
   <ul class="pagination">
    <li><a href=<?php echo '"search.php?s='.$_GET['s'].'&p='.($p-1).'&onuf='.$onuf.'"'; ?>><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span></a></li>
  <?php
    $i = 0;
    do {
      if($i+1 == $p){
        echo '<li class="active">';
      }else{
        echo '<li>';
      }
      echo '<a href="search.php?s='.$_GET['s'].'&p='.($i+1).'&onuf='.$onuf.'">'.($i+1).'</a></li>';
      $i++;
    } while ($i < ceil(count($results)/$nbpage));
    ?>
    <li>
    <a href=<?php echo '"search.php?s='.$_GET['s'].'&p='.($p+1).'&onuf='.$onuf.'"'; ?>><span class=" glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
    </li>
  </ul>
</div>
</div>
</div>
</div>

</body>