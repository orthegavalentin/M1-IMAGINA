<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>OufSearch - Sujet</title>
  <script src="views/js/jquery-2.1.1.min.js"></script>
  <script src="views/js/bootstrap.min.js"></script>
  <script src="views/js/oufJS.js"></script>
  <link href="views/css/bootstrap.min.css" rel="stylesheet">
  <link href="views/css/oufStyle.css" rel="stylesheet">
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
    </head>

    <body>

     <div id="headerBar"></div>

     <div class="container">
      <div class="row clearfix">
       <div class="col-md-3 column">
        <a href="index.php"><h1 class="text-center styleLogo">OUFSEARCH</h1></a>
      </div>
      <div class="col-md-9 column">
        <form class="navbar-form" role="search" method="GET" action="search.php">
         <div class="input-group input-group-lg">
          <input type="text" class="form-control" placeholder="Entrez votre recherche..." name="s">
          <div class="input-group-btn">
           <button type="submit" class="btn btn-primary" aria-label="Rechercher">
            <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="row clearfix">
 <div class="col-md-12 column">

  <!--PANEL PRINCIPAL (TITRE)-->
  <div class="panel panel-primary panel-topic-first">
   <div class="panel-heading">
    <h3 style="display:inline;"><?php echo $topic['sujet']; ?></h3>
    <button idtopic=<?php echo '"'.$topic['id'].'"'; ?> type="button" class=<?php echo '"btn btn-sm pull-right '.$isFollowed.'"'; ?>><span class="glyphicon glyphicon-star"></span></button>
  </div>
  <div class="panel-body lead">
    <p>
      <?php 
      $str = nl2br($reponses[0]['message']);
      echo replace_links($str);
      ?></p>
    </div>
    <div class="panel-footer">
      Posté le : <?php echo $reponses[0]['date']; ?>
    </div>
  </div>

  <?php for($i = 1; $i < count($reponses); $i++){?>
  <div class="panel panel-default panel-topic">
    <div class="panel-body lead">
      <p>
        <?php
        $str =  nl2br($reponses[$i]['message']);
        echo replace_links($str);
        ?>
      </p>
    </div>
    <div class="panel-footer">
      Posté le : <?php echo $reponses[$i]['date'] ?>
      <div class="btn-group btn-group-sm" style="float:right;">
        <button type="button" class="btn btn-success" <?php echo 'onclick="voter('.$reponses[$i]['id'].', 1);"'; ?>><span class="glyphicon glyphicon-thumbs-up"></span></button>
        <button type="button" class="btn btn-danger" <?php echo 'onclick="voter('.$reponses[$i]['id'].', -1);"'; ?>><span class="glyphicon glyphicon-thumbs-down"></span></button>
        <button type="button" class= <?php echo '"btn btn-info inactive post'.$reponses[$i]['id'].'"'; ?> ><?php echo $reponses[$i]['note'] ?></button>
      </div>
    </div>
  </div>
  <?php } ?>

</div>
</div>

<div class="row clearfix">
 <div class="col-md-12 column">
  <nav class="navbar navbar-default navbar-fixed-bottom container-fluid barre-reponse" role="navigation">
   <p class="navbar-repondre lead text-uppercase" href="#">
    <span class="flecheReponse glyphicon glyphicon-chevron-up" aria-hidden="true"></span> Répondre <span class="flecheReponse glyphicon glyphicon-chevron-up" aria-hidden="true"></span>
  </p>
</nav>
</div>
</div>
<div class="row clearfix">
 <div class="col-md-12 column">
  <div class="formulaire-reponse jourNuit">
   <h3 class="text-center text-primary">Répondre</h3>
   <form class="form-horizontal" role="form" method="POST" action=<?php  echo '"answer.php?id='.$_GET['id'].'"'; ?>>
    <div class="form-group">
     <label for="messageTopic" class="col-sm-2 control-label input-lg">Message</label>
     <div class="col-sm-10">
      <textarea class="form-control input-lg" id="messageTopic" rows="5" placeholder="Bonjour, ..." name="message"></textarea>
    </div>
  </div>
  <div class="form-group">
   <div class="col-sm-offset-2 col-sm-10">
    <button type="submit" class="btn btn-primary">Envoyer</button>
  </div>
</div>
</form>
</div>
</div>
</div>
</div>

</body>