$(function () {
	//enlever/ajouter un tag dans les résultats de recherche
	$(".btn-tag").click(function () {
		$(this).toggleClass("disabled");
	});

	//affichage du formulaire de réponse sur une page de topic
	$(".barre-reponse").click(function() {
		$(".formulaire-reponse").toggleClass("jourNuit");
		$(".flecheReponse").toggleClass("glyphicon-chevron-up glyphicon-chevron-down");
	});


  $('.panel-heading button').click(function(){
    var val = $(this).attr('idtopic');
    var save = $(this);
    $.get('ajaxfollow.php?id='+val, function(e){
      save.removeClass("btn-warning btn-sucess").addClass(e);
    });

  });


$('.ouftags').click(function(e){
    var valeur = $(this).text();
    var url = document.URL;
    var tamer = url.split("&onuf");

    if(tamer.length > 1){
      //si déjà des oufs

      url = tamer[0];

      onufs = tamer[1].split("|");
      onufs[0] = onufs[0].substr(1, onufs[0].length);

      

      var premier = true;
      var trouve = false;
      
      for(var i in onufs){
        if(onufs[i] != encodeURIComponent(valeur)){
          if(premier){
            url += "&onuf="+onufs[i];
            premier = false;
          }else{
            url += "|"+onufs[i];
          }
        }else{
          trouve = true;
        }
      }

      if(!trouve){
        url += "|"+encodeURIComponent(valeur);
      }
    }else{
      //url += "&onuf="+valeur.replace("#", "%23");
      url += "&onuf="+encodeURIComponent(valeur);
    }
    document.location.href= url;
  });
  



























});


function voter(id, note){
	var xmlhttp;
	if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  }
  else
  {// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function()
  {
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
  	{
      if(xmlhttp.responseText != "no"){
        document.getElementsByClassName("post"+id)[0].innerHTML = xmlhttp.responseText;
      }
    }
  }
  xmlhttp.open("GET",'ajaxvote.php?id='+id+'&note='+note,true);
  xmlhttp.send();
}
