<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OufSearch - Accueil</title>
    <script src="views/js/jquery-2.1.1.min.js"></script>
    <script src="views/js/bootstrap.min.js"></script>
    <script src="views/js/oufJS.js"></script>
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link href="views/css/oufStyle.css" rel="stylesheet">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
  </head>

  <body>

    <div id="headerBar"></div>

    <div class="container">
        <div class="row clearfix">
            <div class="col-md-12 column">
                <!--<img alt="oufSearch_Logo" class="img-responsive" src="img/OufSearchLogo3.png" />-->
                <h1 class="text-center logoAccueil styleLogo">OUFSEARCH</h3>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-md-12 column">
                    <form class="navbar-form" role="search" method="GET" action="search.php">
                        <div class="input-group input-group-lg">
                                <input type="text" class="form-control" placeholder="Entrez votre recherche..." name="s">
                                <div class="input-group-btn">
                                    <button type="submit" class="btn btn-primary" aria-label="Rechercher">
                                        <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
                                    </button>
                                </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-md-12 column">
                    <div class="row clearfix">
                        <div class="col-md-4 column">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><strong>Derniers Sujets</strong></h3>
                                </div>
                                <ul class="list-unstyled">
                                    <?php foreach (getBlocInformations(':last_topics') as $val) { ?>
                                        <li class="list-group-item">
                                            <span class="badge"><?php echo $val['nb'] ?></span><a href=<?php echo '"topic.php?id='.$val['id'].'"'; ?>><?php echo $val['sujet'] ?></a>
                                        </li>
                                    <?php } ?>
                                </ul>
                                <div class="panel-footer panel-button">
                                    <a href="search.php?s=:last_topics"><button type="button" class="btn btn-sm btn-default btn-block"><span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 column">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><strong>Dernières réponses</strong></h3>
                                </div>
                                <ul class="list-unstyled">
                                    <?php foreach (getBlocInformations(':last_messages') as $val) { ?>
                                        <li class="list-group-item">
                                             <span class="badge"><?php echo $val['nb'] ?></span><a href=<?php echo '"topic.php?id='.$val['id'].'"'; ?>><?php echo $val['sujet'] ?></a>
                                        </li>
                                    <?php } ?>
                                </ul>
                                <div class="panel-footer panel-button">
                                    <a href="search.php?s=:last_messages"><button type="button" class="btn btn-sm btn-default btn-block"><span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 column">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><strong>Sujets Populaires</strong></h3>
                                </div>
                                <ul class="list-unstyled">
                                    <?php foreach (getBlocInformations(':popular') as $val) { ?>
                                        <li class="list-group-item">
                                             <span class="badge"><?php echo $val['nb'] ?></span><a href=<?php echo '"topic.php?id='.$val['id'].'"'; ?>><?php echo $val['sujet'] ?></a>
                                        </li>
                                    <?php } ?>
                                </ul>
                                <div class="panel-footer panel-button">
                                    <a href="search.php?s=:popular"><button type="button" class="btn btn-sm btn-default btn-block"><span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-4 column">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><strong>Mes Favoris</strong></h3>
                                </div>
                                <ul class="list-unstyled">
                                  <?php foreach (getBlocInformations(':followed') as $val) { ?>
                                        <li class="list-group-item">
                                            <span class="badge"><?php echo $val['nb'] ?></span><a href=<?php echo '"topic.php?id='.$val['id'].'"'; ?>><?php echo $val['sujet'] ?></a>
                                        </li>
                                    <?php } ?>
                                </ul>
                                <div class="panel-footer panel-button">
                                    <a href="search.php?s=:followed"><button type="button" class="btn btn-sm btn-default btn-block"><span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 column">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><strong>Mes dernières participations</strong></h3>
                                </div>
                                <ul class="list-unstyled">
                                    <?php foreach (getBlocInformations(':participated') as $val) { ?>
                                        <li class="list-group-item">
                                            <span class="badge"><?php echo $val['nb'] ?></span><a href=<?php echo '"topic.php?id='.$val['id'].'"'; ?>><?php echo $val['sujet'] ?></a>
                                        </li>
                                    <?php } ?>
                                </ul>
                                <div class="panel-footer panel-button">
                                    <a href="search.php?s=:participated"><button type="button" class="btn btn-sm btn-default btn-block"><span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 column">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><strong>OufTags populaires</strong></h3>
                                </div>
                                <ul class="list-unstyled">
                                    <?php foreach (getBlocInformations(':ouftags') as $val) { ?>
                                        <li class="list-group-item">
                                            <span class="badge"><?php echo $val['nb'] ?></span><a href=<?php echo '"search.php?s='.str_replace('#', "%23", $val['ouftag']).'"'; ?>><?php echo $val['ouftag']; ?></a>
                                        </li>
                                    <?php } ?>
                                </ul>
                                <div class="panel-footer panel-button">
                                    <!--<a href="search.php?s=:participated"><button type="button" class="btn btn-sm btn-default btn-block"><span class="glyphicon glyphicon-chevron-down" aria-hidden="true"></span></a>
                                    </button>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>


    </body>

    </html>