<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>OufSearch - Sujet</title>
	<script src="js/jquery-2.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/oufJS.js"></script>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/oufStyle.css" rel="stylesheet">
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
  </head>

  <body>

  	<div id="headerBar"></div>

  	<div class="container">
  		<div class="row clearfix">
  			<div class="col-md-3 column">
  				<h1 class="text-center styleLogo">OUFSEARCH</h1>
  			</div>
  			<div class="col-md-9 column">
  				<form class="navbar-form" role="search">
  					<div class="input-group input-group-lg">
  						<input type="text" class="form-control" placeholder="Entrez votre recherche...">
  						<div class="input-group-btn">
  							<button type="submit" class="btn btn-primary" aria-label="Rechercher">
  								<span class="glyphicon glyphicon-search" aria-hidden="true"></span>
  							</button>
  						</div>
  					</div>
  				</form>
  			</div>
  		</div>

  		<div class="row clearfix">
  			<div class="col-md-12 column">

  				<!--PANEL PRINCIPAL (TITRE)-->
  				<div class="panel panel-primary panel-topic-first">
  					<div class="panel-heading">
  						<h3 class="panel-title">Comment fonctionne Pythagore ?</h3>
  					</div>
  					<div class="panel-body lead">
  						<p>Bonjour, je voudrais savoir comment fonctionne le théorème de Pythagore, pouvez-vous me l'expliquer ? Merci.</p>
  					</div>
  					<div class="panel-footer">
  						Posté le : 21/12/2012
  					</div>
  				</div>
  				<!--FIN PANEL PRINCIPAL-->

  				<!--PANEL DE REPONSE CLASSIQUE-->
  				<div class="panel panel-default panel-topic">
  					<div class="panel-body lead">
  						<p>Voici le théorème de Pythagore : a² + b² = c².</p>
  					</div>
  					<div class="panel-footer">
  						Posté le : 22/12/2012
  						<div class="btn-group btn-group-sm pull-right">
  							<button type="button" class="btn btn-success"><span class="glyphicon glyphicon-thumbs-up"></span></button>
  							<button type="button" class="btn btn-danger" ><span class="glyphicon glyphicon-thumbs-down"></span></button>
  							<button type="button" class="btn btn-info inactive" >4</button>
  						</div>
  					</div>
  				</div>
  				<!--FIN PANEL CLASSIQUE-->

  				<div class="panel panel-default panel-topic">
  					<div class="panel-body lead">
  						<p>Merci, mais aurais-tu un schéma ?</p>
  					</div>
  					<div class="panel-footer">
  						Posté le : 22/12/2012
  						<div class="btn-group btn-group-sm pull-right">
  							<button type="button" class="btn btn-success"><span class="glyphicon glyphicon-thumbs-up"></span></button>
  							<button type="button" class="btn btn-danger" ><span class="glyphicon glyphicon-thumbs-down"></span></button>
  							<button type="button" class="btn btn-info inactive" >0</button>
  						</div>
  					</div>
  				</div>

  				<div class="panel panel-success panel-topic">
  					<div class="panel-heading">
  						<h3 class="panel-title">Meilleure réponse</h3>
  					</div>
  					<div class="panel-body lead">
  						<p>Voici un schéma :</p>
  						<img class="img-thumbnail" src="http://lorempixel.com/280/140/" />
  					</div>
  					<div class="panel-footer">
  						Posté le : 23/12/2012
  						<div class="btn-group btn-group-sm pull-right">
  							<button type="button" class="btn btn-success"><span class="glyphicon glyphicon-thumbs-up"></span></button>
  							<button type="button" class="btn btn-danger" ><span class="glyphicon glyphicon-thumbs-down"></span></button>
  							<button type="button" class="btn btn-info inactive" >12</button>
  						</div>
  					</div>
  				</div>

  				<div class="panel panel-default panel-topic">
  					<div class="panel-body lead">
  						<p>Merci beaucoup ! Bonne fin de semaine :)</p>
  					</div>
  					<div class="panel-footer">
  						Posté le : 23/12/2012
  						<div class="btn-group btn-group-sm pull-right">
  							<button type="button" class="btn btn-success"><span class="glyphicon glyphicon-thumbs-up"></span></button>
  							<button type="button" class="btn btn-danger" ><span class="glyphicon glyphicon-thumbs-down"></span></button>
  							<button type="button" class="btn btn-info inactive" >1</button>
  						</div>
  					</div>
  				</div>

  			</div>
  		</div>

  		<div class="row clearfix">
  			<div class="col-md-12 column">
  				<nav class="navbar navbar-default navbar-fixed-bottom container-fluid barre-reponse" role="navigation">
  					<p class="navbar-repondre lead text-uppercase" href="#">
  						<span class="flecheReponse glyphicon glyphicon-chevron-up" aria-hidden="true"></span> Répondre <span class="flecheReponse glyphicon glyphicon-chevron-up" aria-hidden="true"></span>
  					</p>
  				</nav>
  			</div>
  		</div>
  		<div class="row clearfix">
  			<div class="col-md-12 column">
  				<div class="formulaire-reponse jourNuit">
	  				<h3 class="text-center text-primary">Répondre</h3>
	  				<form class="form-horizontal" role="form">
	  					<div class="form-group">
	  						<label for="messageTopic" class="col-sm-2 control-label input-lg">Message</label>
	  						<div class="col-sm-10">
	  							<textarea class="form-control input-lg" id="messageTopic" rows="5" placeholder="Bonjour, ..."></textarea>
	  						</div>
	  					</div>
	  					<div class="form-group">
	  						<div class="col-sm-offset-2 col-sm-10">
	  							<button type="submit" class="btn btn-primary">Envoyer</button>
	  						</div>
	  					</div>
	  				</form>
	  			</div>
  			</div>
  		</div>


  	</div>
  </body>