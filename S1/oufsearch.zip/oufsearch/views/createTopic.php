<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>OufSearch - Nouveau Sujet</title>
	<script src="views/js/jquery-2.1.1.min.js"></script>
	<script src="views/js/bootstrap.min.js"></script>
	<script src="views/js/oufJS.js"></script>
	<link href="views/css/bootstrap.min.css" rel="stylesheet">
	<link href="views/css/oufStyle.css" rel="stylesheet">
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
  </head>

  <body>

  	<div id="headerBar"></div>
  	<div class="container">

  		<div class="row clearfix">
  			<div class="col-md-3 column">
  				<h1 class="text-center styleLogo">OUFSEARCH</h1>
  			</div>
  			<div class="col-md-9 column">
  				<form class="navbar-form" role="search">
  					<div class="input-group input-group-lg">
  						<input type="text" class="form-control" placeholder="Entrez votre recherche...">
  						<div class="input-group-btn">
  							<button type="submit" class="btn btn-primary" aria-label="Rechercher">
  								<span class="glyphicon glyphicon-search" aria-hidden="true"></span>
  							</button>
  						</div>
  					</div>
  				</form>
  			</div>
  		</div>

  		<div class="row clearfix">
  			<div class="col-md-12 column">
  				<h3 class="text-center text-primary">Créer un nouveau sujet</h3>
  				<form class="form-horizontal" role="form">
  					<div class="form-group">
  						<label for="titreSujet" class="col-sm-2 control-label input-lg">Titre du Sujet</label>
  						<div class="col-sm-10">
  							<input class="form-control input-lg" id="titreSujet" type="text" />
  						</div>
  					</div>
  					<div class="form-group">
  						<label for="messageTopic" class="col-sm-2 control-label input-lg">Message</label>
  						<div class="col-sm-10">
  							<textarea class="form-control input-lg" id="messageTopic" rows="5" placeholder="Bonjour, ..."></textarea>
  						</div>
  					</div>
  					<div class="form-group">
  						<div class="col-sm-offset-2 col-sm-10">
  							<div class="checkbox">
  								<label>
  									<input type="checkbox" />Ajouter à Mes Favoris
  								</label>
  							</div>
  						</div>
  					</div>
  					<div class="form-group">
  						<div class="col-sm-offset-2 col-sm-10">
  							<button type="submit" class="btn btn-primary">Envoyer</button>
  						</div>
  					</div>
  				</form>
  			</div>
  		</div>
  	</div>

  </body>