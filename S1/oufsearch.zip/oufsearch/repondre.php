<?php
if(isset($_POST['message'])){
	addMessage($_POST['message'], $_GET['id']);
	$ouftags = getOufTagFromString($_POST['message']);
	foreach ($ouftags as $ouf) {
		addOuftag($ouf);
	}
	header("Location:".WEBROOT.'?p=topic&id='.$_GET['id']);
}